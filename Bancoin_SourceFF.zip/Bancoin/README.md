Bancoin
=======
Bancoin (BCT) nace como criptoactivo el 4 Diciembre de 2018 para fundar las bases de la nueva era bancaria en blockchain creando BANCOIN(www.mibancoin.com) como casa de cambio, banco digital y multiples servicios financieros, dando así el ejemplo siendo el primer banco creado desde un criptoactivo para su financiamiento inicial y gestión en consenso, segura en una cadena de bloques propia, diseñado para funcionar como participación accionaria del proyecto Bancoin "La nueva Banca y comercio digital, libertad financiera, Dinero donde sea." y por lo tanto servir como voto en decisiones de la red y dividendos de la plataforma como una empresa digital y banca de nueva era.

Caracteristicas Tecnicas:
=========================
Nombre: Bancoin
Ticker: BCT
Algoritmo: Scrypt
Puerto P2P: 9853
Puerto RPC: 9852
Monedas por bloque: 0.0951293759 BCT
Porcentaje de PoS Anual: 20%
Tiempo minimo para Stake: 6 Horas
Tiempo Maximo para Stake: 30 Dias.
Bloques necesarios para confirmar: 6
Cantidad Maxima de Monedas: 33666999
Preminado: 5050049.85 (15%)